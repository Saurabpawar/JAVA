class Box{

private int wid,dep,hi,res;

//No Argument Constructor
public Box()
{

 /* wid=4;
  dep= 4;
 hi= 4;*/
this(4,4,4);
}

 
//copy constructor
public Box(Box cp)
{

  wid=cp.wid;
  dep=cp.dep;
 hi=cp.hi;

}

//fully parameterised Constructor
public Box(int a,int b,int c)
{

  this.wid=a;
  this.dep=b;
 this.hi=c;

}

public void volBox()
{
  res = wid*dep*hi;
System.out.println("Volume="+res);
}

}

////////////////////////////////////MAIN/////////////////////////////////

class ass3{

public static void main(String[] args)
{
  

Box d1 = new Box();
	d1.volBox();

Box d2 = new Box(d1);

	d2.volBox();
Box d3 = new Box();
	d3.volBox();
}

}