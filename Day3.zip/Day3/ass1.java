class Date{

private int dd,mm,yy;

//No Argument Constructor
public Date()
{

  dd=2;
  mm= 4;
 yy= 1945;

}


public void showDate()
{
  System.out.println(dd +"-"+mm+"-"+yy);
}

}



class ass1{

public static void main(String[] args)
{
  


Date d1 = new Date();
	d1.showDate();


}

}