class Cord{

private int x,y;

//Default Constructor
public Cord()
{

  x=15;
 y= 20;

}

 //parameterised Constructor
public Cord(int xx,int yy)
{

  x=xx;;
 y=yy;

}

public void showCord()
{
  System.out.println(x+","+y);
}

}

/////////////////////////////////////////////////////////////////////

class ass4{

public static void main(String[] args)
{
  

Cord d1 = new Cord();
	d1.showCord();

Cord d2 = new Cord(10,19);
	d2.showCord();

}

}