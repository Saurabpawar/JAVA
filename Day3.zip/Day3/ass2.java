class Date{

private int dd,mm,yy;

//No Argument Constructor
public Date()
{

  dd=2;
  mm= 4;
 yy= 1945;

}


 //parameterised Constructor
public Date(int d,int m,int y)
{

  dd=d;
  mm=m;
 yy=y;

}

public void showDate()
{
  System.out.println(dd +"-"+mm+"-"+yy);
}

}



/////////////////////////////////////////////////////////////////////



class ass2{

public static void main(String[] args)
{
  

Date d1 = new Date();
	d1.showDate();

Date d2 = new Date(6,10,1999);
	d2.showDate();

}

}