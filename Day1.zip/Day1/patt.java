public class patt{
public static void main(String[] args){

int nrows=5;
for(int row=1 ; row<=nrows; row++)
{
for(int sp =row ; sp<=nrows; sp++)
System.out.print("  ");

for(int col =1 ; col<=row; col++)
System.out.print(col+ " ");

for(int col1 =row-1 ; col1>=1; col1--)
System.out.print(col1+ " ");
System.out.println();
}
}}