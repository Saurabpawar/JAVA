import java.util.*;
public class ass4{
public static void main(String[] args){

System.out.println("Enter number ");
Scanner sc=new Scanner (System.in);
int a=sc.nextInt();

for (int i=1; i<=a; i++)
{
if( a%i == 0 )
{
System.out.println(i);
}}
}
}
