import java.util.*;
public class ass2{
public static void main(String[] args){

System.out.println("Enter 3 number");
Scanner sc = new Scanner (System.in);
int a = sc.nextInt();
int b = sc.nextInt();
int c = sc.nextInt();

if(a>b && a>c)
{
System.out.println("Bigger number is " + a);
}
else if (b>a && b>c)
{
System.out.println("Bigger number is " + b);
}
else
{System.out.println("Bigger number is " + c);
}
}}