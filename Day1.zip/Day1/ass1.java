import java.util.*;

public class ass1{
public static void main(String[] args){

System.out.println("Enter number");
Scanner sc= new Scanner(System.in);
int a=sc.nextInt();


if (a%2 == 0){
System.out.println("Even number");
}
else {
System.out.println("Odd number");

}}} 