import java.util.Scanner;
public class Arrass{
public static void main(String[] args){

	Scanner sc = new Scanner(System.in);
    int[] arr = new int[10];
	for(int i=0; i<args.length; i++){

		 
	arr[i]=Integer.parseInt(args[i]);
	}
	
		 

System.out.println("Enter choice \n 1: Display\n 2: Sum\n 3: MinMax\n 4: PerfectorNot\n 5: PrimeorNot\n 6: Reverse\n 7: Second smallest\n 8: Second largest\n 9: Ascending sort\n 10: Descending");
int n = sc.nextInt();
int z = 0;
switch(n)
{case 1:
	for( int i=0; i<arr.length; i++){
	System.out.println( arr[i] + " ");
	}
	break;
case 2:
	
	System.out.println("sum of array elements are ");
	for(int i=0; i<arr.length; i++)
	{
		z=arr[i]+z;

	}System.out.println(z);
	break;

case 3:
	int max = arr[0];
	for(int i=0; i<arr.length; i++){
	 if(max<arr[i]){
		max=arr[i];		
		}
	}
	
	int min = arr[0];
	for(int i=0; i<arr.length; i++){
	 if(min>arr[i]){
		min=arr[i];		
		}
	}

	System.out.println("Max element is " + max + "\n" + "Min element is" + min );
	break;

case 4:
	for(int i=0; i<arr.length; i++){
	int sum=0;
	for(int j=1; j<arr[i] ; j++)
		{if(arr[i]%j==0){
         
		sum = sum+j;
		}
		}
	
		if(sum == arr[i]){
		System.out.println( arr[i] + " is perfect no \n");}
		else{
		System.out.println( arr[i] + " is not perfect no \n");
        }
	}break;

case 5:

for(int i=0; i<arr.length; i++){
	int sum=1;
	for(int j=1; j<arr[i] ; j++)
		{if(arr[i]%j==0){
         
		sum++;
		}
		}
	
		if(sum == 2){
		System.out.println( arr[i] + " is prime \n");}
		else{
		System.out.println( arr[i] + " not prime no \n");
        }
	}break;

case 6:
	for( int i=arr.length - 1; i>0; i--){
	System.out.println( arr[i] + " ");
	}
	break;
case 7:
        int min1 = arr[0];
        int min2 = arr[1];

	for(int i=0 ; i<arr.length; i++){
	 if(min1>arr[i]){
		min2=min1;
                min1=arr[i];
	}}

System.out.println(min1 + " " + min2);
break;



default:
System.out.println("invalid case");

}
}
}