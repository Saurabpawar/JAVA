class Students{
int rollno = 32;
String name;
int div;
public int rollcall()
{
return rollno;
}
}

class Coustomer{
int id;
String name;
int sales;
public int coust()
{
return id;
}
}

class Account{
int accnum;
String name;
int ifsccode;
public int Acc()
{
return accnum;
}
}

class Mobile{
int modelnum;
String name;
int makeyear;
public int mob()
{
return modelnum;
}
}




public class ass1{
public static void main(String[] args){

Students b1=new Students();

System.out.println(b1.rollcall());
}
}